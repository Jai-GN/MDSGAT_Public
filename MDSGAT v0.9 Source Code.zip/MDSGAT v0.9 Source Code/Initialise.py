# Required for Installer


def main():
    import MDSGAT_GUI
    
if __name__ == "__main__":
    main()

